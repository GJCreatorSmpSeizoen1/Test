-- Nexora: basisschema met Row Level Security.
-- Toepassen: supabase db push  (of plak in de Supabase SQL-editor)

create extension if not exists pgcrypto;

-- ---------- Hulpfuncties ----------
create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- Profiles ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 40),
  role text not null default 'user' check (role in ('user','moderator','admin')),
  is_active boolean not null default true,
  notify_email boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_updated before update on public.profiles
  for each row execute function public.set_updated_at();

-- Wordt in RLS-policies gebruikt. security definer voorkomt recursie op profiles.
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles
                 where id = auth.uid() and role = 'admin' and is_active)
$$;

-- Gebruikers mogen hun eigen rol of actief-status nooit wijzigen.
-- auth.uid() is null bij service-role/SQL-editor: dan is wijzigen toegestaan.
create or replace function public.guard_profile_privileged() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_admin()
     and (new.role is distinct from old.role or new.is_active is distinct from old.is_active) then
    raise exception 'Alleen beheerders mogen rol of status wijzigen';
  end if;
  return new;
end $$;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.guard_profile_privileged();

-- Profiel automatisch aanmaken bij registratie.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(nullif(left(new.raw_user_meta_data->>'display_name', 40), ''),
                           left(split_part(new.email, '@', 1), 40)));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
create policy "profiles: eigen profiel lezen" on public.profiles for select using (id = auth.uid());
create policy "profiles: admin leest alles" on public.profiles for select using (public.is_admin());
create policy "profiles: eigen profiel wijzigen" on public.profiles for update
  using (id = auth.uid()) with check (id = auth.uid());
create policy "profiles: admin wijzigt alles" on public.profiles for update
  using (public.is_admin()) with check (public.is_admin());

-- ---------- Projects ----------
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 60),
  status text not null default 'planned' check (status in ('planned','active','done')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index projects_owner_created_idx on public.projects (owner_id, created_at desc);
create trigger projects_updated before update on public.projects
  for each row execute function public.set_updated_at();
alter table public.projects enable row level security;
create policy "projects: eigenaar beheert" on public.projects for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "projects: admin leest" on public.projects for select using (public.is_admin());

-- ---------- Conversations & messages ----------
create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null default 'Nieuw gesprek' check (char_length(title) <= 120),
  created_at timestamptz not null default now()
);
create index conversations_owner_created_idx on public.conversations (owner_id, created_at desc);
alter table public.conversations enable row level security;
create policy "conversations: eigenaar beheert" on public.conversations for all
  using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) <= 20000),
  created_at timestamptz not null default now()
);
create index messages_conv_created_idx on public.messages (conversation_id, created_at);
alter table public.messages enable row level security;
create policy "messages: eigenaar beheert" on public.messages for all
  using (owner_id = auth.uid()
         and exists (select 1 from public.conversations c where c.id = conversation_id and c.owner_id = auth.uid()))
  with check (owner_id = auth.uid()
         and exists (select 1 from public.conversations c where c.id = conversation_id and c.owner_id = auth.uid()));

-- ---------- Notifications ----------
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) <= 120),
  body text check (char_length(body) <= 1000),
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_user_unread_idx on public.notifications (user_id, created_at desc) where read_at is null;
alter table public.notifications enable row level security;
create policy "notifications: eigen meldingen lezen" on public.notifications for select using (user_id = auth.uid());
create policy "notifications: eigen meldingen markeren" on public.notifications for update
  using (user_id = auth.uid()) with check (user_id = auth.uid());
-- Aanmaken gebeurt alleen server-side (service role), daarom geen insert-policy.

-- ---------- Audit logs ----------
create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_type text,
  target_id text,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs (created_at desc);
alter table public.audit_logs enable row level security;
create policy "audit_logs: admin leest" on public.audit_logs for select using (public.is_admin());
-- Schrijven gebeurt alleen server-side (service role). Geen update/delete-policies: de log is onveranderbaar voor gebruikers.
