import type { Config } from "tailwindcss";

// Design tokens komen 1-op-1 uit design/preview-reference.html
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "var(--bg)",
        panel: "var(--panel)",
        panel2: "var(--panel2)",
        line: "var(--line)",
        fg: "var(--text)",
        mut: "var(--mut)",
        pri: { DEFAULT: "var(--pri)", soft: "var(--pri2)" },
        accent: "var(--blue)",
        ok: "var(--ok)",
        warn: "var(--warn)",
        bad: "var(--bad)",
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      borderRadius: { card: "14px" },
    },
  },
  plugins: [],
};
export default config;
