// Tijdelijke startpagina. De echte landingpage en navigatie volgen in stap 2.
export default function Home() {
  return (
    <main className="mx-auto max-w-2xl px-6 py-24">
      <h1 className="text-4xl font-bold">Nexora</h1>
      <p className="mt-4 text-mut">
        Het fundament van de applicatie staat. Pagina&apos;s, inloggen en projecten worden in de volgende stappen toegevoegd.
      </p>
    </main>
  );
}
