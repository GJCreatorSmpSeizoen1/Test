# Nexora voortgang

Status: "Geschreven" betekent code aanwezig maar nog NIET gedraaid. "Getest" pas afvinken na een echte run.

## Stap 1: fundament
- [x] Projectconfiguratie geschreven (Next.js, strict TypeScript, Tailwind met design-tokens uit de preview)
- [x] Supabase-clients en middleware geschreven
- [x] Databasemigratie met RLS geschreven (supabase/migrations/0001_init.sql)
- [ ] npm install, typecheck en build gedraaid
- [ ] Migratie toegepast op een echt Supabase-project

## Stap 2: pagina's en auth (nog niet gebouwd)
- [ ] Layout met zijbalk en mobiele navigatie
- [ ] Registratie, login, wachtwoordherstel
- [ ] Dashboard, projecten (CRUD), instellingen
## Stap 3: AI Studio, chat, adminpaneel, scripts, tests (nog niet gebouwd)
