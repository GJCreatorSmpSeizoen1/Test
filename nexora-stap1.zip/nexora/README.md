# Nexora

Next.js (App Router) + TypeScript + Tailwind + Supabase. Design: zie `design/preview-reference.html`.

Status: alleen het fundament (stap 1). Zie `TODO.md`.

## Lokaal starten
```bash
npm install
cp .env.example .env.local   # vul de Supabase-waarden in
npm run typecheck && npm run build
npm run dev
```

## Database
1. Maak een project op supabase.com.
2. Voer `supabase/migrations/0001_init.sql` uit in de SQL-editor (of `supabase db push` met de Supabase CLI).
3. Maak jezelf later beheerder via de SQL-editor: `update public.profiles set role = 'admin' where id = '<jouw user-id>';`

## Vercel
```bash
npm i -g vercel
vercel          # preview
vercel --prod   # productie
```
Stel dezelfde variabelen als in `.env.example` in bij Vercel > Settings > Environment Variables.
