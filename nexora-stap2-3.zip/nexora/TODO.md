# Nexora voortgang

Legenda: "Geschreven" = code aanwezig maar NIET gedraaid. "Getest" = echt uitgevoerd (zie opmerking per regel).

## Stap 1: fundament
- [x] Configuratie, Supabase-clients, middleware, migratie met RLS: geschreven
- [ ] npm install, typecheck en build: nog niet gedraaid (geen internet in de bouwomgeving)
- [ ] Migratie toegepast op een echt Supabase-project

## Stap 2: pagina's en auth
- [x] Landingpage, functies, privacy- en voorwaarden-concept: geschreven
- [x] App-layout met zijbalk en mobiele onderbalk: geschreven
- [x] Registratie, login, wachtwoord vergeten/resetten, callback, uitloggen: geschreven
- [x] Dashboard, projecten (CRUD, zoeken, filter, paginering), instellingen: geschreven
- [x] Loading-, fout- en niet-gevonden-pagina's: geschreven
- [ ] Alles hierboven in een browser en tegen een echte Supabase uitgeprobeerd

## Stap 3: AI, admin, scripts, tests
- [x] AI Studio en chat via /api/ai/generate en /api/chat (server-side, time-out, rate limit): geschreven, niet gedraaid, nooit tegen de echte API aangeroepen
- [x] Adminpaneel (gebruikers, rollen, blokkeren, auditlog), server-side autorisatie: geschreven
- [x] /api/health en scripts (healthcheck, cleanup met dry-run): geschreven, niet gedraaid
- [x] Vitest-tests: 4 bestanden geschreven. Pure helpers (safe-redirect, rate-limit, projects) zijn gedraaid via een Node-shim, NIET via Vitest. validation.test.ts is niet gedraaid (vereist zod).
- [x] Playwright smoke-tests geschreven, niet gedraaid

## Nog niet gebouwd
- [ ] Notificatiepagina, abonnementen/facturatie, helpcentrum
- [ ] Admin: foutlogs, contentbeheer, functieconfiguratie
- [ ] Uploads, geplande taken (cron), e-mailmeldingen, import/export
- [ ] Rate limiting met gedeelde opslag (huidige limiter is per serverinstance)
- [ ] Account verwijderen
- [ ] Accessibility- en mobiele controle in een echte browser
