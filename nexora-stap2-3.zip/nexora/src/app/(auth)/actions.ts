"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { forgotSchema, loginSchema, newPasswordSchema, registerSchema } from "@/lib/validation";
import { rateLimit } from "@/lib/rate-limit";
import { safeNext } from "@/lib/safe-redirect";
import type { ActionState } from "@/lib/types";

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "");
const invalid = (fieldErrors: ActionState["fieldErrors"], values?: ActionState["values"]): ActionState => ({
  error: "Controleer de gemarkeerde velden.", fieldErrors, values,
});

async function clientIp() {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() || "onbekend";
}
async function siteUrl() {
  const h = await headers();
  return h.get("origin") ?? process.env.NEXT_PUBLIC_SITE_URL ?? "";
}
function tooMany(sec: number): ActionState {
  return { error: `Te veel pogingen. Probeer het over ${Math.max(1, Math.ceil(sec / 60))} min opnieuw.` };
}

export async function registerAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const values = { displayName: str(fd, "displayName"), email: str(fd, "email") };
  const parsed = registerSchema.safeParse({ ...values, password: str(fd, "password") });
  if (!parsed.success) return invalid(parsed.error.flatten().fieldErrors, values);
  const rl = rateLimit(`register:${await clientIp()}`, 5, 15 * 60_000);
  if (!rl.ok) return tooMany(rl.retryAfterSec);

  const site = await siteUrl();
  if (!site) return { error: "NEXT_PUBLIC_SITE_URL is niet ingesteld.", values };
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: { data: { display_name: parsed.data.displayName }, emailRedirectTo: `${site}/auth/callback?next=/dashboard` },
  });
  if (error) return { error: "Registreren is niet gelukt. Controleer je gegevens of probeer het later opnieuw.", values };
  if (data.session) redirect("/dashboard");
  return { ok: true, message: "Bijna klaar: bevestig je e-mailadres via de link die we je hebben gestuurd." };
}

export async function loginAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const values = { email: str(fd, "email") };
  const parsed = loginSchema.safeParse({ ...values, password: str(fd, "password") });
  if (!parsed.success) return invalid(parsed.error.flatten().fieldErrors, values);
  const rl = rateLimit(`login:${await clientIp()}:${parsed.data.email}`, 8, 15 * 60_000);
  if (!rl.ok) return tooMany(rl.retryAfterSec);

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) return { error: "E-mailadres of wachtwoord klopt niet.", values };
  redirect(safeNext(str(fd, "next")));
}

export async function forgotAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const values = { email: str(fd, "email") };
  const parsed = forgotSchema.safeParse(values);
  if (!parsed.success) return invalid(parsed.error.flatten().fieldErrors, values);
  const rl = rateLimit(`forgot:${await clientIp()}`, 3, 15 * 60_000);
  if (!rl.ok) return tooMany(rl.retryAfterSec);

  const site = await siteUrl();
  if (!site) return { error: "NEXT_PUBLIC_SITE_URL is niet ingesteld.", values };
  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(parsed.data.email, { redirectTo: `${site}/auth/callback?next=/wachtwoord-resetten` });
  // Altijd hetzelfde antwoord, zodat niet te zien is welke e-mailadressen bestaan.
  return { ok: true, message: "Als dit e-mailadres bij een account hoort, sturen we je een link om een nieuw wachtwoord in te stellen." };
}

export async function newPasswordAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = newPasswordSchema.safeParse({ password: str(fd, "password"), confirm: str(fd, "confirm") });
  if (!parsed.success) return invalid(parsed.error.flatten().fieldErrors);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "Deze link is verlopen. Vraag een nieuwe aan via 'Wachtwoord vergeten'." };
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) return { error: "Wachtwoord wijzigen is niet gelukt. Kies een ander wachtwoord of vraag een nieuwe link aan." };
  redirect("/dashboard");
}

export async function signOutAction() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}
