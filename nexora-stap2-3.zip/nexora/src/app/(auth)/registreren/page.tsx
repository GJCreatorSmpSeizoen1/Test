import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { ConfigMissing } from "@/components/config-missing";
import { isSupabaseConfigured } from "@/lib/env";
import { getSessionProfile } from "@/lib/auth";
import { RegisterForm } from "../auth-forms";

export const metadata: Metadata = { title: "Account aanmaken" };

export default async function RegisterPage() {
  if (!isSupabaseConfigured()) return <ConfigMissing />;
  const { user } = await getSessionProfile();
  if (user) redirect("/dashboard");
  return <RegisterForm />;
}
