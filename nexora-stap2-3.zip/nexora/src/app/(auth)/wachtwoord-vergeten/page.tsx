import type { Metadata } from "next";
import { ConfigMissing } from "@/components/config-missing";
import { isSupabaseConfigured } from "@/lib/env";
import { ForgotForm } from "../auth-forms";

export const metadata: Metadata = { title: "Wachtwoord vergeten" };

export default function ForgotPage() {
  if (!isSupabaseConfigured()) return <ConfigMissing />;
  return <ForgotForm />;
}
