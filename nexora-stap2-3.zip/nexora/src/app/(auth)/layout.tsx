import Link from "next/link";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6 py-10">
      <Link href="/" className="brand mb-6" style={{ padding: 0 }}>Nexora</Link>
      <div className="card">{children}</div>
    </main>
  );
}
