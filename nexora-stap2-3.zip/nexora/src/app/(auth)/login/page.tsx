import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { ConfigMissing } from "@/components/config-missing";
import { isSupabaseConfigured } from "@/lib/env";
import { safeNext } from "@/lib/safe-redirect";
import { getSessionProfile } from "@/lib/auth";
import { LoginForm } from "../auth-forms";

export const metadata: Metadata = { title: "Inloggen" };
const NOTICES: Record<string, string> = {
  link: "Deze link is ongeldig of verlopen. Vraag een nieuwe aan.",
  geblokkeerd: "Dit account is geblokkeerd. Neem contact op met de beheerder.",
};

export default async function LoginPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  if (!isSupabaseConfigured()) return <ConfigMissing />;
  const sp = await searchParams;
  const pick = (k: string) => { const v = sp[k]; return Array.isArray(v) ? v[0] : v; };
  const next = safeNext(pick("next"));
  const { user } = await getSessionProfile();
  if (user) redirect(next);
  const fout = pick("fout");
  return <LoginForm next={next} notice={fout ? NOTICES[fout] : undefined} />;
}
