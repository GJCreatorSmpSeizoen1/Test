import type { Metadata } from "next";
import Link from "next/link";
import { ConfigMissing } from "@/components/config-missing";
import { isSupabaseConfigured } from "@/lib/env";
import { getSessionProfile } from "@/lib/auth";
import { NewPasswordForm } from "../auth-forms";

export const metadata: Metadata = { title: "Nieuw wachtwoord" };

export default async function ResetPage() {
  if (!isSupabaseConfigured()) return <ConfigMissing />;
  const { user } = await getSessionProfile();
  if (!user) {
    return (
      <div className="space-y-3">
        <h1 className="text-2xl font-bold">Link verlopen</h1>
        <p className="text-mut">Deze link werkt niet meer. Vraag een nieuwe aan.</p>
        <Link href="/wachtwoord-vergeten" className="btn">Nieuwe link aanvragen</Link>
      </div>
    );
  }
  return <NewPasswordForm />;
}
