"use client";

import Link from "next/link";
import { useActionState } from "react";
import { Field } from "@/components/field";
import { FormMessage } from "@/components/form-message";
import { SubmitButton } from "@/components/submit-button";
import type { ActionState } from "@/lib/types";
import { forgotAction, loginAction, newPasswordAction, registerAction } from "./actions";

const initial: ActionState = {};

export function LoginForm({ next, notice }: { next: string; notice?: string }) {
  const [state, action] = useActionState(loginAction, initial);
  return (
    <form action={action} className="space-y-4">
      <h1 className="text-2xl font-bold">Inloggen</h1>
      {notice ? <p role="alert" className="alert alert-warn">{notice}</p> : null}
      <input type="hidden" name="next" value={next} />
      <Field label="E-mailadres" name="email" type="email" autoComplete="email" required defaultValue={state.values?.email} error={state.fieldErrors?.email} />
      <Field label="Wachtwoord" name="password" type="password" autoComplete="current-password" required error={state.fieldErrors?.password} />
      <FormMessage state={state} />
      <SubmitButton pendingText="Inloggen...">Inloggen</SubmitButton>
      <p className="text-sm text-mut"><Link href="/wachtwoord-vergeten" className="underline">Wachtwoord vergeten?</Link> · <Link href="/registreren" className="underline">Account aanmaken</Link></p>
    </form>
  );
}

export function RegisterForm() {
  const [state, action] = useActionState(registerAction, initial);
  return (
    <form action={action} className="space-y-4">
      <h1 className="text-2xl font-bold">Account aanmaken</h1>
      <Field label="Naam" name="displayName" autoComplete="name" required maxLength={40} defaultValue={state.values?.displayName} error={state.fieldErrors?.displayName} />
      <Field label="E-mailadres" name="email" type="email" autoComplete="email" required defaultValue={state.values?.email} error={state.fieldErrors?.email} />
      <Field label="Wachtwoord" name="password" type="password" autoComplete="new-password" required minLength={10} maxLength={72} hint="Minimaal 10 tekens." error={state.fieldErrors?.password} />
      <FormMessage state={state} />
      <SubmitButton pendingText="Account aanmaken...">Account aanmaken</SubmitButton>
      <p className="text-sm text-mut">Heb je al een account? <Link href="/login" className="underline">Inloggen</Link></p>
    </form>
  );
}

export function ForgotForm() {
  const [state, action] = useActionState(forgotAction, initial);
  return (
    <form action={action} className="space-y-4">
      <h1 className="text-2xl font-bold">Wachtwoord vergeten</h1>
      <p className="text-mut">Vul je e-mailadres in. Je krijgt een link om een nieuw wachtwoord te kiezen.</p>
      <Field label="E-mailadres" name="email" type="email" autoComplete="email" required defaultValue={state.values?.email} error={state.fieldErrors?.email} />
      <FormMessage state={state} />
      <SubmitButton pendingText="Versturen...">Link versturen</SubmitButton>
      <p className="text-sm text-mut"><Link href="/login" className="underline">Terug naar inloggen</Link></p>
    </form>
  );
}

export function NewPasswordForm() {
  const [state, action] = useActionState(newPasswordAction, initial);
  return (
    <form action={action} className="space-y-4">
      <h1 className="text-2xl font-bold">Nieuw wachtwoord</h1>
      <Field label="Nieuw wachtwoord" name="password" type="password" autoComplete="new-password" required minLength={10} maxLength={72} error={state.fieldErrors?.password} />
      <Field label="Herhaal wachtwoord" name="confirm" type="password" autoComplete="new-password" required error={state.fieldErrors?.confirm} />
      <FormMessage state={state} />
      <SubmitButton pendingText="Opslaan...">Wachtwoord opslaan</SubmitButton>
    </form>
  );
}
