"use client";

import { useState } from "react";

const MODES = [
  { v: "free", l: "Vrije vraag" }, { v: "summarize", l: "Samenvatten" }, { v: "rewrite", l: "Herschrijven" }, { v: "ideas", l: "Ideeën bedenken" },
];

export function StudioForm({ aiReady }: { aiReady: boolean }) {
  const [prompt, setPrompt] = useState("");
  const [mode, setMode] = useState("free");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState("");
  const [error, setError] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(""); setResult("");
    try {
      const res = await fetch("/api/ai/generate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ prompt, mode }) });
      const data = (await res.json()) as { text?: string; message?: string };
      if (!res.ok) setError(data.message ?? "Er ging iets mis. Probeer het opnieuw.");
      else setResult(data.text ?? "");
    } catch {
      setError("Geen verbinding met de server. Controleer je internet en probeer het opnieuw.");
    } finally { setBusy(false); }
  }

  return (
    <div className="space-y-4">
      {!aiReady ? <p role="alert" className="alert alert-warn"><strong>AI is nog niet ingesteld.</strong> Een beheerder moet ANTHROPIC_API_KEY als serveromgevingsvariabele toevoegen. Tot die tijd geeft Nexora geen AI-antwoorden.</p> : null}
      <form onSubmit={submit} className="card space-y-4">
        <div><label className="label" htmlFor="mode">Wat wil je doen?</label>
          <select id="mode" className="input" value={mode} onChange={(e) => setMode(e.target.value)}>{MODES.map((m) => <option key={m.v} value={m.v}>{m.l}</option>)}</select></div>
        <div><label className="label" htmlFor="prompt">Je tekst of vraag</label>
          <textarea id="prompt" className="input" style={{ minHeight: 140 }} value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={4000} required /></div>
        <button className="btn" type="submit" disabled={busy || !aiReady || !prompt.trim()} aria-busy={busy}>{busy ? "Bezig met genereren..." : "Genereren"}</button>
      </form>
      {error ? <p role="alert" className="alert alert-err">{error}</p> : null}
      {result ? (
        <div className="card space-y-3" aria-live="polite">
          <h2 className="text-lg font-semibold">Resultaat</h2>
          <p className="whitespace-pre-wrap">{result}</p>
          <button className="btn btn-ghost btn-sm" type="button" onClick={() => navigator.clipboard?.writeText(result)}>Kopiëren</button>
        </div>
      ) : null}
    </div>
  );
}
