import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { aiConfigured } from "@/lib/env";
import { StudioForm } from "./studio-form";

export const metadata: Metadata = { title: "AI Studio" };

export default async function StudioPage() {
  await requireUser();
  return (
    <div className="max-w-3xl space-y-6">
      <div><h1 className="text-3xl font-bold">AI Studio</h1><p className="mt-1 text-mut">Laat tekst samenvatten, herschrijven of aanvullen met ideeën.</p></div>
      <StudioForm aiReady={aiConfigured()} />
    </div>
  );
}
