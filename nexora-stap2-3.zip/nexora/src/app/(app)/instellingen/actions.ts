"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { newPasswordSchema, profileSchema } from "@/lib/validation";
import type { ActionState } from "@/lib/types";

export async function updateProfileAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { user } = await requireUser();
  const values = { displayName: String(fd.get("displayName") ?? "") };
  const parsed = profileSchema.safeParse({ displayName: values.displayName, notifyEmail: fd.get("notifyEmail") === "on" });
  if (!parsed.success) return { error: "Controleer de gemarkeerde velden.", fieldErrors: parsed.error.flatten().fieldErrors, values };
  const supabase = await createClient();
  // Alleen eigen, niet-geprivilegieerde kolommen; rol en status worden door de database beschermd.
  const { error } = await supabase.from("profiles").update({ display_name: parsed.data.displayName, notify_email: parsed.data.notifyEmail }).eq("id", user.id);
  if (error) return { error: "Opslaan is niet gelukt. Probeer het opnieuw.", values };
  revalidatePath("/", "layout");
  return { ok: true, message: "Profiel opgeslagen." };
}

export async function changePasswordAction(_: ActionState, fd: FormData): Promise<ActionState> {
  await requireUser();
  const parsed = newPasswordSchema.safeParse({ password: String(fd.get("password") ?? ""), confirm: String(fd.get("confirm") ?? "") });
  if (!parsed.success) return { error: "Controleer de gemarkeerde velden.", fieldErrors: parsed.error.flatten().fieldErrors };
  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password: parsed.data.password });
  if (error) return { error: "Wachtwoord wijzigen is niet gelukt. Kies een ander wachtwoord." };
  return { ok: true, message: "Wachtwoord gewijzigd." };
}
