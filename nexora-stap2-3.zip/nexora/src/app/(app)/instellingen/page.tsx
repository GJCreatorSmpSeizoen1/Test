import type { Metadata } from "next";
import { signOutAction } from "@/app/(auth)/actions";
import { requireUser } from "@/lib/auth";
import { PasswordForm, ProfileForm } from "./settings-forms";

export const metadata: Metadata = { title: "Instellingen" };

export default async function InstellingenPage() {
  const { user, profile } = await requireUser();
  return (
    <div className="max-w-xl space-y-6">
      <h1 className="text-3xl font-bold">Instellingen</h1>
      <ProfileForm displayName={profile.display_name} email={user.email ?? ""} notifyEmail={profile.notify_email} />
      <PasswordForm />
      <form action={signOutAction}><button className="btn btn-ghost" type="submit">Uitloggen</button></form>
    </div>
  );
}
