"use client";

import { useActionState } from "react";
import { Field } from "@/components/field";
import { FormMessage } from "@/components/form-message";
import { SubmitButton } from "@/components/submit-button";
import type { ActionState } from "@/lib/types";
import { changePasswordAction, updateProfileAction } from "./actions";

export function ProfileForm({ displayName, email, notifyEmail }: { displayName: string; email: string; notifyEmail: boolean }) {
  const [state, action] = useActionState(updateProfileAction, {} as ActionState);
  return (
    <form action={action} className="card space-y-4">
      <h2 className="text-xl font-semibold">Profiel</h2>
      <Field label="Naam" name="displayName" required maxLength={40} defaultValue={state.values?.displayName ?? displayName} error={state.fieldErrors?.displayName} />
      <div><label className="label" htmlFor="email-ro">E-mailadres</label><input id="email-ro" className="input" value={email} readOnly aria-readonly="true" /></div>
      <label className="flex items-center gap-3"><input type="checkbox" name="notifyEmail" defaultChecked={notifyEmail} className="h-5 w-5 accent-[var(--pri)]" /> E-mailmeldingen ontvangen</label>
      <FormMessage state={state} />
      <SubmitButton pendingText="Opslaan...">Profiel opslaan</SubmitButton>
    </form>
  );
}

export function PasswordForm() {
  const [state, action] = useActionState(changePasswordAction, {} as ActionState);
  return (
    <form action={action} className="card space-y-4">
      <h2 className="text-xl font-semibold">Wachtwoord wijzigen</h2>
      <Field label="Nieuw wachtwoord" name="password" type="password" autoComplete="new-password" required minLength={10} maxLength={72} error={state.fieldErrors?.password} />
      <Field label="Herhaal wachtwoord" name="confirm" type="password" autoComplete="new-password" required error={state.fieldErrors?.confirm} />
      <FormMessage state={state} />
      <SubmitButton pendingText="Opslaan...">Wachtwoord wijzigen</SubmitButton>
    </form>
  );
}
