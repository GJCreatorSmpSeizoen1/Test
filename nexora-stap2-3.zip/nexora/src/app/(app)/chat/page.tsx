import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { aiConfigured } from "@/lib/env";
import { createClient } from "@/lib/supabase/server";
import { uuidSchema } from "@/lib/validation";
import type { ChatMessage } from "@/lib/types";
import { ChatPanel } from "./chat-panel";

export const metadata: Metadata = { title: "Chat" };

export default async function ChatPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const c = Array.isArray(sp.c) ? sp.c[0] : sp.c;
  const { user } = await requireUser();
  const supabase = await createClient();

  const { data: convs } = await supabase.from("conversations").select("id,title,created_at").eq("owner_id", user.id).order("created_at", { ascending: false }).limit(20);
  const list = (convs ?? []) as { id: string; title: string }[];

  const id = uuidSchema.safeParse(c);
  let messages: ChatMessage[] = [];
  let activeId: string | undefined;
  if (id.success) {
    const { data } = await supabase.from("messages").select("role,content").eq("conversation_id", id.data).order("created_at", { ascending: true }).limit(200);
    if (data) { messages = data as ChatMessage[]; activeId = id.data; }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[240px_1fr]">
      <aside aria-label="Gesprekken" className="space-y-2">
        <Link href="/chat" className="btn btn-ghost btn-sm w-full">Nieuw gesprek</Link>
        {list.length === 0 ? <p className="text-sm text-mut">Nog geen bewaarde gesprekken.</p> : (
          <ul className="space-y-1">{list.map((x) => (
            <li key={x.id}><Link href={`/chat?c=${x.id}`} aria-current={x.id === activeId ? "page" : undefined} className={`block truncate rounded-lg px-3 py-2 text-sm ${x.id === activeId ? "bg-pri/20" : "text-mut hover:bg-panel2"}`}>{x.title}</Link></li>
          ))}</ul>
        )}
      </aside>
      <section className="space-y-4">
        <h1 className="text-3xl font-bold">Chat</h1>
        <ChatPanel key={activeId ?? "nieuw"} initialMessages={messages} conversationId={activeId} aiReady={aiConfigured()} />
      </section>
    </div>
  );
}
