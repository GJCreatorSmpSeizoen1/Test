"use client";

import { useRouter } from "next/navigation";
import { useRef, useState } from "react";
import type { ChatMessage } from "@/lib/types";

export function ChatPanel({ initialMessages, conversationId, aiReady }: { initialMessages: ChatMessage[]; conversationId?: string; aiReady: boolean }) {
  const router = useRouter();
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [convId, setConvId] = useState(conversationId);
  const [save, setSave] = useState(Boolean(conversationId));
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text) return;
    setBusy(true); setError(""); setInput("");
    const history = messages.slice(-20);
    setMessages((m) => [...m, { role: "user", content: text }]);
    try {
      const res = await fetch("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message: text, save, conversationId: convId, history: save && convId ? [] : history }) });
      const data = (await res.json()) as { text?: string; message?: string; conversationId?: string | null };
      if (data.text) setMessages((m) => [...m, { role: "assistant", content: data.text as string }]);
      if (!res.ok) setError(data.message ?? "Er ging iets mis. Probeer het opnieuw.");
      if (data.conversationId && data.conversationId !== convId) { setConvId(data.conversationId); router.replace(`/chat?c=${data.conversationId}`); router.refresh(); }
    } catch {
      setError("Geen verbinding met de server. Probeer het opnieuw.");
    } finally {
      setBusy(false);
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    }
  }

  return (
    <div className="space-y-4">
      {!aiReady ? <p role="alert" className="alert alert-warn"><strong>AI is nog niet ingesteld.</strong> Zonder ANTHROPIC_API_KEY op de server krijg je geen antwoorden.</p> : null}
      <div className="card min-h-[300px] space-y-3" aria-live="polite">
        {messages.length === 0 ? <p className="py-10 text-center text-mut">Stel je eerste vraag om het gesprek te starten.</p> : null}
        {messages.map((m, i) => (
          <div key={i} className={m.role === "user" ? "ml-auto max-w-[85%] rounded-xl bg-pri/20 px-4 py-2" : "mr-auto max-w-[85%] rounded-xl bg-panel2 px-4 py-2"}>
            <div className="mb-0.5 text-xs text-mut">{m.role === "user" ? "Jij" : "Assistent"}</div>
            <p className="whitespace-pre-wrap">{m.content}</p>
          </div>
        ))}
        {busy ? <p className="text-sm text-mut">De assistent schrijft...</p> : null}
        <div ref={endRef} />
      </div>
      {error ? <p role="alert" className="alert alert-err">{error}</p> : null}
      <form onSubmit={send} className="space-y-3">
        <label className="label" htmlFor="msg">Bericht</label>
        <textarea id="msg" className="input" style={{ minHeight: 90 }} value={input} onChange={(e) => setInput(e.target.value)} maxLength={4000} required />
        <div className="flex flex-wrap items-center justify-between gap-3">
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={save} onChange={(e) => setSave(e.target.checked)} className="h-5 w-5 accent-[var(--pri)]" /> Gesprek bewaren</label>
          <button className="btn" type="submit" disabled={busy || !aiReady || !input.trim()} aria-busy={busy}>{busy ? "Versturen..." : "Versturen"}</button>
        </div>
      </form>
    </div>
  );
}
