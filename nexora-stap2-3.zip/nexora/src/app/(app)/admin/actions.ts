"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { createServiceClient } from "@/lib/supabase/admin";
import { roleSchema, uuidSchema } from "@/lib/validation";

function service() { try { return createServiceClient(); } catch { return null; } }

// Elke actie controleert opnieuw server-side of de aanroeper beheerder is; de UI is geen beveiliging.
export async function setRoleAction(fd: FormData) {
  const { user } = await requireAdmin();
  const id = uuidSchema.safeParse(fd.get("id"));
  const role = roleSchema.safeParse(fd.get("role"));
  if (!id.success || !role.success) redirect("/admin?fout=ongeldig");
  if (id.data === user.id) redirect("/admin?fout=zelf");
  const svc = service();
  if (!svc) redirect("/admin?fout=audit"); // zonder auditlog voeren we geen beheeractie uit

  const supabase = await createClient();
  const { data: before } = await supabase.from("profiles").select("role").eq("id", id.data).maybeSingle();
  const { error } = await supabase.from("profiles").update({ role: role.data }).eq("id", id.data);
  if (error) redirect("/admin?fout=opslaan");
  const { error: logErr } = await svc.from("audit_logs").insert({ actor_id: user.id, action: "user.role_changed", target_type: "profile", target_id: id.data, meta: { from: (before as { role?: string } | null)?.role ?? null, to: role.data } });
  revalidatePath("/admin");
  if (logErr) redirect("/admin?fout=auditmislukt");
}

export async function setActiveAction(fd: FormData) {
  const { user } = await requireAdmin();
  const id = uuidSchema.safeParse(fd.get("id"));
  if (!id.success) redirect("/admin?fout=ongeldig");
  const active = fd.get("active") === "true";
  if (id.data === user.id) redirect("/admin?fout=zelf");
  const svc = service();
  if (!svc) redirect("/admin?fout=audit");

  const supabase = await createClient();
  const { error } = await supabase.from("profiles").update({ is_active: active }).eq("id", id.data);
  if (error) redirect("/admin?fout=opslaan");
  const { error: logErr } = await svc.from("audit_logs").insert({ actor_id: user.id, action: active ? "user.unblocked" : "user.blocked", target_type: "profile", target_id: id.data, meta: {} });
  revalidatePath("/admin");
  if (logErr) redirect("/admin?fout=auditmislukt");
}
