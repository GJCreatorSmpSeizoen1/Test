import type { Metadata } from "next";
import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PAGE_SIZE, escapeLike, pageRange, parsePage } from "@/lib/projects";
import type { Profile } from "@/lib/types";
import { setActiveAction, setRoleAction } from "./actions";

export const metadata: Metadata = { title: "Admin" };
const ERRORS: Record<string, string> = {
  ongeldig: "Ongeldige invoer.",
  zelf: "Je kunt je eigen rol of status niet wijzigen. Vraag een andere beheerder.",
  opslaan: "Wijzigen is niet gelukt.",
  audit: "Actie geweigerd: de auditlog is niet beschikbaar (SUPABASE_SERVICE_ROLE_KEY ontbreekt op de server).",
  auditmislukt: "De wijziging is doorgevoerd, maar de auditlog kon niet worden bijgewerkt. Controleer de serverconfiguratie.",
};
const ACTIONS: Record<string, string> = { "user.role_changed": "Rol gewijzigd", "user.blocked": "Gebruiker geblokkeerd", "user.unblocked": "Gebruiker gedeblokkeerd", "maintenance.cleanup_notifications": "Opschoning meldingen" };

export default async function AdminPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const { user } = await requireAdmin();
  const sp = await searchParams;
  const pick = (k: string) => { const v = sp[k]; return Array.isArray(v) ? v[0] : v; };
  const q = (pick("q") ?? "").trim().slice(0, 40);
  const page = parsePage(pick("page"));
  const { from, to } = pageRange(page);
  const supabase = await createClient();

  let users = supabase.from("profiles").select("id,display_name,role,is_active,created_at", { count: "exact" }).order("created_at", { ascending: false }).range(from, to);
  if (q) users = users.ilike("display_name", `%${escapeLike(q)}%`);
  const [usersRes, totalUsers, activeUsers, totalProjects, audit] = await Promise.all([
    users,
    supabase.from("profiles").select("id", { count: "exact", head: true }),
    supabase.from("profiles").select("id", { count: "exact", head: true }).eq("is_active", true),
    supabase.from("projects").select("id", { count: "exact", head: true }),
    supabase.from("audit_logs").select("id,action,actor_id,target_id,meta,created_at").order("created_at", { ascending: false }).limit(15),
  ]);
  const rows = (usersRes.data ?? []) as Profile[];
  const totalPages = Math.max(1, Math.ceil((usersRes.count ?? 0) / PAGE_SIZE));
  const names = new Map(rows.map((r) => [r.id, r.display_name]));
  const fout = pick("fout");
  const href = (p: number) => `/admin?${new URLSearchParams({ ...(q ? { q } : {}), ...(p > 1 ? { page: String(p) } : {}) }).toString()}`;

  return (
    <div className="space-y-8">
      <div><h1 className="text-3xl font-bold">Admin</h1><p className="mt-1 text-mut">Gebruikers, rollen en het logboek van beheeracties.</p></div>
      {fout && ERRORS[fout] ? <p role="alert" className="alert alert-err">{ERRORS[fout]}</p> : null}
      {usersRes.error ? <p role="alert" className="alert alert-err">Gebruikers laden is niet gelukt.</p> : null}

      <div className="grid gap-4 sm:grid-cols-3">
        {[["Gebruikers", totalUsers.count], ["Actief", activeUsers.count], ["Projecten", totalProjects.count]].map(([l, n]) => (
          <div key={String(l)} className="card"><div className="text-sm text-mut">{l}</div><div className="font-display text-3xl font-bold">{n ?? 0}</div></div>
        ))}
      </div>

      <section className="space-y-3">
        <h2 className="text-xl font-semibold">Gebruikers</h2>
        <form method="get" role="search" className="flex gap-3"><input className="input" type="search" name="q" defaultValue={q} placeholder="Zoek op naam" aria-label="Zoek gebruiker op naam" maxLength={40} /><button className="btn btn-ghost" type="submit">Zoeken</button></form>
        <div className="card tw">
          <table className="tbl">
            <thead><tr><th>Naam</th><th>Rol</th><th>Status</th><th><span className="sr-only">Acties</span></th></tr></thead>
            <tbody>
              {rows.length === 0 ? <tr><td colSpan={4} className="py-6 text-center text-mut">Geen gebruikers gevonden.</td></tr> : rows.map((r) => (
                <tr key={r.id}>
                  <td>{r.display_name}{r.id === user.id ? <span className="ml-2 text-xs text-mut">(jij)</span> : null}</td>
                  <td>
                    <form action={setRoleAction} className="flex gap-2">
                      <input type="hidden" name="id" value={r.id} />
                      <select className="input w-auto" name="role" defaultValue={r.role} disabled={r.id === user.id} aria-label={`Rol van ${r.display_name}`}>
                        <option value="user">Gebruiker</option><option value="moderator">Moderator</option><option value="admin">Beheerder</option>
                      </select>
                      <button className="btn btn-ghost btn-sm" type="submit" disabled={r.id === user.id}>Opslaan</button>
                    </form>
                  </td>
                  <td>{r.is_active ? <span className="tag tag-done">Actief</span> : <span className="tag tag-planned">Geblokkeerd</span>}</td>
                  <td>
                    <form action={setActiveAction}>
                      <input type="hidden" name="id" value={r.id} /><input type="hidden" name="active" value={String(!r.is_active)} />
                      <button className="btn btn-ghost btn-sm" type="submit" disabled={r.id === user.id}>{r.is_active ? "Blokkeren" : "Deblokkeren"}</button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {totalPages > 1 ? (
          <nav aria-label="Paginering" className="flex items-center justify-between text-sm">
            {page > 1 ? <Link className="btn btn-ghost btn-sm" href={href(page - 1)}>Vorige</Link> : <span />}
            <span className="text-mut">Pagina {page} van {totalPages}</span>
            {page < totalPages ? <Link className="btn btn-ghost btn-sm" href={href(page + 1)}>Volgende</Link> : <span />}
          </nav>
        ) : null}
      </section>

      <section className="space-y-3">
        <h2 className="text-xl font-semibold">Auditlog</h2>
        <div className="card">
          {(audit.data ?? []).length === 0 ? <p className="py-4 text-center text-mut">Nog geen beheeracties vastgelegd.</p> : (
            <ul>{(audit.data ?? []).map((a) => {
              const row = a as { id: number; action: string; actor_id: string | null; target_id: string | null; created_at: string };
              return <li key={row.id} className="flex flex-wrap gap-3 border-b border-line py-2 last:border-0"><span className="text-sm text-mut">{new Date(row.created_at).toLocaleString("nl-NL")}</span><span>{ACTIONS[row.action] ?? row.action}</span><span className="text-sm text-mut">door {row.actor_id ? names.get(row.actor_id) ?? row.actor_id.slice(0, 8) : "systeem"}</span></li>;
            })}</ul>
          )}
        </div>
      </section>
      <p className="alert alert-warn text-sm">Nog niet beschikbaar in dit paneel: foutlogs, contentbeheer en functieconfiguratie.</p>
    </div>
  );
}
