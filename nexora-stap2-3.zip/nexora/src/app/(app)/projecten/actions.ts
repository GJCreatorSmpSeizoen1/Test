"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { rateLimit } from "@/lib/rate-limit";
import { parseStatus } from "@/lib/projects";
import { projectNameSchema, uuidSchema } from "@/lib/validation";
import type { ActionState } from "@/lib/types";

const done = () => { revalidatePath("/projecten"); revalidatePath("/dashboard"); };

export async function createProjectAction(_: ActionState, fd: FormData): Promise<ActionState> {
  const { user } = await requireUser();
  const raw = String(fd.get("name") ?? "");
  const parsed = projectNameSchema.safeParse(raw);
  if (!parsed.success) {
    const msg = parsed.error.issues[0]?.message ?? "Ongeldige naam";
    return { error: msg, fieldErrors: { name: [msg] }, values: { name: raw } };
  }
  const rl = rateLimit(`project-create:${user.id}`, 30, 60_000);
  if (!rl.ok) return { error: "Je maakt te snel projecten aan. Wacht even en probeer het opnieuw.", values: { name: raw } };
  const supabase = await createClient();
  const { error } = await supabase.from("projects").insert({ owner_id: user.id, name: parsed.data });
  if (error) return { error: "Project opslaan is niet gelukt. Probeer het opnieuw.", values: { name: raw } };
  done();
  return { ok: true, message: "Project toegevoegd." };
}

export async function updateStatusAction(fd: FormData) {
  const { user } = await requireUser();
  const id = uuidSchema.safeParse(fd.get("id"));
  const status = parseStatus(String(fd.get("status") ?? ""));
  if (!id.success || !status) redirect("/projecten?fout=ongeldig");
  const supabase = await createClient();
  const { error } = await supabase.from("projects").update({ status }).eq("id", id.data).eq("owner_id", user.id);
  if (error) redirect("/projecten?fout=opslaan");
  done();
}

export async function renameProjectAction(fd: FormData) {
  const { user } = await requireUser();
  const id = uuidSchema.safeParse(fd.get("id"));
  const name = projectNameSchema.safeParse(String(fd.get("name") ?? ""));
  if (!id.success || !name.success) redirect("/projecten?fout=ongeldig");
  const supabase = await createClient();
  const { error } = await supabase.from("projects").update({ name: name.data }).eq("id", id.data).eq("owner_id", user.id);
  if (error) redirect("/projecten?fout=opslaan");
  done();
}

export async function deleteProjectAction(fd: FormData) {
  const { user } = await requireUser();
  const id = uuidSchema.safeParse(fd.get("id"));
  if (!id.success) redirect("/projecten?fout=ongeldig");
  const supabase = await createClient();
  const { error } = await supabase.from("projects").delete().eq("id", id.data).eq("owner_id", user.id);
  if (error) redirect("/projecten?fout=verwijderen");
  done();
}
