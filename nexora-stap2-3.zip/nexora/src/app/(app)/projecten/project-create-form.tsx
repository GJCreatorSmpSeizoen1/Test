"use client";

import { useActionState } from "react";
import { Field } from "@/components/field";
import { FormMessage } from "@/components/form-message";
import { SubmitButton } from "@/components/submit-button";
import type { ActionState } from "@/lib/types";
import { createProjectAction } from "./actions";

export function ProjectCreateForm() {
  const [state, action] = useActionState(createProjectAction, {} as ActionState);
  return (
    <form action={action} className="space-y-3">
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-[220px] flex-1">
          <Field label="Nieuw project" name="name" required maxLength={60} autoComplete="off" placeholder="Bijvoorbeeld: Lancering Q1" defaultValue={state.values?.name} error={state.fieldErrors?.name} />
        </div>
        <SubmitButton pendingText="Toevoegen...">Project toevoegen</SubmitButton>
      </div>
      {state.ok ? <FormMessage state={state} /> : state.fieldErrors?.name ? null : <FormMessage state={state} />}
    </form>
  );
}
