import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { PAGE_SIZE, STATUSES, STATUS_LABEL, escapeLike, nextStatus, pageRange, parsePage, parseStatus } from "@/lib/projects";
import type { Project } from "@/lib/types";
import { deleteProjectAction, renameProjectAction, updateStatusAction } from "./actions";
import { ProjectCreateForm } from "./project-create-form";

export const metadata: Metadata = { title: "Projecten" };
const ERRORS: Record<string, string> = {
  ongeldig: "Ongeldige invoer. Controleer je gegevens en probeer het opnieuw.",
  opslaan: "Wijzigen is niet gelukt. Probeer het opnieuw.",
  verwijderen: "Verwijderen is niet gelukt. Probeer het opnieuw.",
};

export default async function ProjectenPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const pick = (k: string) => { const v = sp[k]; return Array.isArray(v) ? v[0] : v; };
  const { user } = await requireUser();
  const q = (pick("q") ?? "").trim().slice(0, 60);
  const status = parseStatus(pick("status"));
  const page = parsePage(pick("page"));
  const { from, to } = pageRange(page);

  const supabase = await createClient();
  let query = supabase.from("projects").select("id,name,status,created_at", { count: "exact" }).eq("owner_id", user.id).order("created_at", { ascending: false }).range(from, to);
  if (q) query = query.ilike("name", `%${escapeLike(q)}%`);
  if (status) query = query.eq("status", status);
  const { data, count, error } = await query;
  const projects = (data ?? []) as Project[];
  const total = count ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const href = (p: number) => {
    const u = new URLSearchParams();
    if (q) u.set("q", q);
    if (status) u.set("status", status);
    if (p > 1) u.set("page", String(p));
    const s = u.toString();
    return `/projecten${s ? `?${s}` : ""}`;
  };
  const fout = pick("fout");

  return (
    <div className="space-y-6">
      <div><h1 className="text-3xl font-bold">Projecten</h1><p className="mt-1 text-mut">{total} {total === 1 ? "project" : "projecten"}</p></div>
      {fout && ERRORS[fout] ? <p role="alert" className="alert alert-err">{ERRORS[fout]}</p> : null}
      {error ? <p role="alert" className="alert alert-err">Projecten laden is niet gelukt. Vernieuw de pagina.</p> : null}
      <div className="card"><ProjectCreateForm /></div>

      <form method="get" className="flex flex-wrap gap-3" role="search">
        <input className="input min-w-[200px] flex-1" type="search" name="q" defaultValue={q} placeholder="Zoek in projecten" aria-label="Zoek in projecten" maxLength={60} />
        <select className="input w-auto" name="status" defaultValue={status ?? ""} aria-label="Filter op status">
          <option value="">Alle statussen</option>
          {STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
        </select>
        <button className="btn btn-ghost" type="submit">Filteren</button>
      </form>

      <div className="card">
        {projects.length === 0 ? (
          <p className="py-8 text-center text-mut">{q || status ? "Geen projecten gevonden voor deze zoekopdracht." : "Nog geen projecten. Voeg hierboven je eerste project toe."}</p>
        ) : (
          <ul>
            {projects.map((p) => (
              <li key={p.id} className="flex flex-wrap items-center gap-3 border-b border-line py-3 last:border-0">
                <div className="min-w-[160px] flex-1"><strong>{p.name}</strong><div className="text-sm text-mut">{new Date(p.created_at).toLocaleDateString("nl-NL")}</div></div>
                <span className={`tag tag-${p.status}`}>{STATUS_LABEL[p.status]}</span>
                <form action={updateStatusAction}>
                  <input type="hidden" name="id" value={p.id} /><input type="hidden" name="status" value={nextStatus(p.status)} />
                  <button className="btn btn-ghost btn-sm" type="submit">Zet op {STATUS_LABEL[nextStatus(p.status)].toLowerCase()}</button>
                </form>
                <details>
                  <summary className="btn btn-ghost btn-sm cursor-pointer list-none">Hernoemen</summary>
                  <form action={renameProjectAction} className="mt-2 flex gap-2">
                    <input type="hidden" name="id" value={p.id} />
                    <input className="input" name="name" defaultValue={p.name} maxLength={60} required aria-label={`Nieuwe naam voor ${p.name}`} />
                    <button className="btn btn-sm" type="submit">Opslaan</button>
                  </form>
                </details>
                <details>
                  <summary className="btn btn-danger btn-sm cursor-pointer list-none">Verwijderen</summary>
                  <form action={deleteProjectAction} className="mt-2 flex items-center gap-2">
                    <input type="hidden" name="id" value={p.id} />
                    <span className="text-sm">Zeker weten?</span>
                    <button className="btn btn-danger btn-sm" type="submit">Ja, verwijder</button>
                  </form>
                </details>
              </li>
            ))}
          </ul>
        )}
      </div>

      {totalPages > 1 ? (
        <nav aria-label="Paginering" className="flex items-center justify-between text-sm">
          {page > 1 ? <Link className="btn btn-ghost btn-sm" href={href(page - 1)}>Vorige</Link> : <span />}
          <span className="text-mut">Pagina {page} van {totalPages}</span>
          {page < totalPages ? <Link className="btn btn-ghost btn-sm" href={href(page + 1)}>Volgende</Link> : <span />}
        </nav>
      ) : null}
    </div>
  );
}
