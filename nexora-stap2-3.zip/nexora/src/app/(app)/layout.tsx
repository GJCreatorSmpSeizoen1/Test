import { redirect } from "next/navigation";
import { AppNav } from "@/components/app-nav";
import { ConfigMissing } from "@/components/config-missing";
import { getSessionProfile } from "@/lib/auth";
import { isSupabaseConfigured } from "@/lib/env";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  if (!isSupabaseConfigured()) return <ConfigMissing />;
  const { user, profile } = await getSessionProfile();
  if (!user) redirect("/login");
  if (!profile) {
    return (
      <main className="mx-auto max-w-xl px-6 py-20">
        <p role="alert" className="alert alert-err">Je profiel is niet gevonden. Controleer of de databasemigratie (supabase/migrations/0001_init.sql) is toegepast.</p>
      </main>
    );
  }
  if (!profile.is_active) redirect("/auth/geblokkeerd");

  const items = [
    { href: "/dashboard", label: "Dashboard" },
    { href: "/projecten", label: "Projecten" },
    { href: "/studio", label: "AI Studio" },
    { href: "/chat", label: "Chat" },
    { href: "/instellingen", label: "Instellingen" },
  ];
  if (profile.role === "admin") items.push({ href: "/admin", label: "Admin" });

  return (
    <div className="shell">
      <a href="#inhoud" className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-pri focus:px-3 focus:py-2">Naar inhoud</a>
      <AppNav items={items} name={profile.display_name} />
      <main className="main" id="inhoud">{children}</main>
    </div>
  );
}
