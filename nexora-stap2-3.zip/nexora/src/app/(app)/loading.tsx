import { Skeleton } from "@/components/skeleton";

export default function Loading() {
  return (
    <div role="status" aria-label="Laden" className="space-y-4">
      <Skeleton className="h-9 w-64" />
      <div className="grid gap-3 sm:grid-cols-3"><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /></div>
      <Skeleton className="h-56" />
    </div>
  );
}
