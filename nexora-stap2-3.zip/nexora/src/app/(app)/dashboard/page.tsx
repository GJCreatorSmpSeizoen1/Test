import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { STATUS_LABEL } from "@/lib/projects";
import type { Project } from "@/lib/types";

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const { user, profile } = await requireUser();
  const supabase = await createClient();
  const count = (status?: string) => {
    let q = supabase.from("projects").select("id", { count: "exact", head: true }).eq("owner_id", user.id);
    if (status) q = q.eq("status", status);
    return q;
  };
  const [all, active, done, recent] = await Promise.all([
    count(),
    count("active"),
    count("done"),
    supabase.from("projects").select("id,name,status,created_at").eq("owner_id", user.id).order("created_at", { ascending: false }).limit(5),
  ]);
  if (all.error || active.error || done.error || recent.error) throw new Error("dashboard-query-failed");
  const projects = (recent.data ?? []) as Project[];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Welkom terug, {profile.display_name}</h1>
        <p className="mt-1 text-mut">Dit is je overzicht.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        {[["Alle projecten", all.count], ["Actief", active.count], ["Afgerond", done.count]].map(([l, n]) => (
          <div key={String(l)} className="card"><div className="text-sm text-mut">{l}</div><div className="font-display text-3xl font-bold">{n ?? 0}</div></div>
        ))}
      </div>
      <section>
        <div className="mb-3 flex items-center justify-between"><h2 className="text-xl font-semibold">Recente projecten</h2><Link href="/projecten" className="text-sm text-pri-soft underline">Alle projecten</Link></div>
        <div className="card">
          {projects.length === 0 ? (
            <p className="py-6 text-center text-mut">Je hebt nog geen projecten. <Link href="/projecten" className="text-pri-soft underline">Maak je eerste project aan</Link>.</p>
          ) : (
            <ul>{projects.map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-3 border-b border-line py-3 last:border-0"><span>{p.name}</span><span className={`tag tag-${p.status}`}>{STATUS_LABEL[p.status]}</span></li>
            ))}</ul>
          )}
        </div>
      </section>
    </div>
  );
}
