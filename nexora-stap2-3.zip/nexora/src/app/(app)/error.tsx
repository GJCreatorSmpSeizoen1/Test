"use client";

export default function AppError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div role="alert" className="alert alert-err space-y-3">
      <strong>Er ging iets mis.</strong>
      <p>De pagina kon niet worden geladen. Probeer het opnieuw. Blijft het misgaan, meld dan deze code: {error.digest ?? "onbekend"}.</p>
      <button className="btn btn-ghost btn-sm" onClick={reset}>Opnieuw proberen</button>
    </div>
  );
}
