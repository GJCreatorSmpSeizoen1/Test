import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto max-w-md px-6 py-24 text-center">
      <h1 className="text-3xl font-bold">Pagina niet gevonden</h1>
      <p className="mt-3 text-mut">Deze pagina bestaat niet of je hebt er geen toegang toe.</p>
      <Link href="/" className="btn mt-6">Naar de startpagina</Link>
    </main>
  );
}
