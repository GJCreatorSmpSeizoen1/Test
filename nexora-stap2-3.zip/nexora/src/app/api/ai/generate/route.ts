import { NextResponse } from "next/server";
import { getSessionProfile } from "@/lib/auth";
import { AiNotConfiguredError, AiUpstreamError, SYSTEM_PROMPTS, generate } from "@/lib/ai";
import { aiConfigured } from "@/lib/env";
import { jsonError } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { aiPromptSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const { user, profile } = await getSessionProfile();
  if (!user || !profile?.is_active) return jsonError(401, "UNAUTHENTICATED", "Log eerst in.");
  if (!aiConfigured()) return jsonError(503, "AI_NOT_CONFIGURED", "De AI-service is nog niet ingesteld. Een beheerder moet ANTHROPIC_API_KEY als serveromgevingsvariabele toevoegen.");

  const rl = rateLimit(`ai:${user.id}`, 20, 60_000);
  if (!rl.ok) return jsonError(429, "RATE_LIMITED", `Te veel aanvragen. Probeer het over ${rl.retryAfterSec} seconden opnieuw.`, undefined, { "Retry-After": String(rl.retryAfterSec) });

  let body: unknown;
  try { body = await req.json(); } catch { return jsonError(400, "INVALID_JSON", "Ongeldige aanvraag."); }
  const parsed = aiPromptSchema.safeParse(body);
  if (!parsed.success) return jsonError(400, "INVALID_INPUT", parsed.error.issues[0]?.message ?? "Ongeldige invoer.", { fieldErrors: parsed.error.flatten().fieldErrors });

  try {
    const text = await generate({ system: SYSTEM_PROMPTS[parsed.data.mode], messages: [{ role: "user", content: parsed.data.prompt }] });
    return NextResponse.json({ text });
  } catch (e) {
    if (e instanceof AiNotConfiguredError) return jsonError(503, "AI_NOT_CONFIGURED", "De AI-service is nog niet ingesteld.");
    console.error("ai.generate mislukt", e instanceof AiUpstreamError ? e.status : "onbekend");
    return jsonError(502, "AI_UPSTREAM", e instanceof AiUpstreamError ? e.message : "De AI-service gaf een fout. Probeer het later opnieuw.");
  }
}
