import { NextResponse } from "next/server";
import { getSessionProfile } from "@/lib/auth";
import { AiNotConfiguredError, AiUpstreamError, SYSTEM_PROMPTS, generate, type AiMessage } from "@/lib/ai";
import { aiConfigured } from "@/lib/env";
import { jsonError } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { createClient } from "@/lib/supabase/server";
import { chatSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const { user, profile } = await getSessionProfile();
  if (!user || !profile?.is_active) return jsonError(401, "UNAUTHENTICATED", "Log eerst in.");
  if (!aiConfigured()) return jsonError(503, "AI_NOT_CONFIGURED", "De AI-service is nog niet ingesteld. Een beheerder moet ANTHROPIC_API_KEY als serveromgevingsvariabele toevoegen.");

  const rl = rateLimit(`chat:${user.id}`, 30, 60_000);
  if (!rl.ok) return jsonError(429, "RATE_LIMITED", `Te veel berichten. Probeer het over ${rl.retryAfterSec} seconden opnieuw.`, undefined, { "Retry-After": String(rl.retryAfterSec) });

  let raw: unknown;
  try { raw = await req.json(); } catch { return jsonError(400, "INVALID_JSON", "Ongeldige aanvraag."); }
  const parsed = chatSchema.safeParse(raw);
  if (!parsed.success) return jsonError(400, "INVALID_INPUT", parsed.error.issues[0]?.message ?? "Ongeldige invoer.");
  const { message, save } = parsed.data;
  let conversationId = parsed.data.conversationId;
  let history: AiMessage[] = parsed.data.history;

  const supabase = await createClient();
  // Bij een bewaard gesprek komt de geschiedenis uit de database (RLS: alleen eigen gesprekken zichtbaar).
  if (save && conversationId) {
    const { data: conv } = await supabase.from("conversations").select("id").eq("id", conversationId).maybeSingle();
    if (!conv) return jsonError(404, "NOT_FOUND", "Dit gesprek bestaat niet.");
    const { data: rows, error } = await supabase.from("messages").select("role,content").eq("conversation_id", conversationId).order("created_at", { ascending: false }).limit(20);
    if (error) return jsonError(500, "DB_ERROR", "Gesprek laden is niet gelukt.");
    history = ((rows ?? []) as AiMessage[]).reverse();
  }

  let reply: string;
  try {
    reply = await generate({ system: SYSTEM_PROMPTS.chat, messages: [...history, { role: "user", content: message }] });
  } catch (e) {
    if (e instanceof AiNotConfiguredError) return jsonError(503, "AI_NOT_CONFIGURED", "De AI-service is nog niet ingesteld.");
    console.error("chat mislukt", e instanceof AiUpstreamError ? e.status : "onbekend");
    return jsonError(502, "AI_UPSTREAM", e instanceof AiUpstreamError ? e.message : "De AI-service gaf een fout. Probeer het later opnieuw.");
  }

  if (save) {
    if (!conversationId) {
      const { data, error } = await supabase.from("conversations").insert({ owner_id: user.id, title: message.slice(0, 60) }).select("id").single();
      if (error || !data) return jsonError(500, "DB_ERROR", "Het antwoord is gemaakt, maar het gesprek bewaren is niet gelukt.", { text: reply });
      conversationId = (data as { id: string }).id;
    }
    const { error } = await supabase.from("messages").insert([
      { conversation_id: conversationId, owner_id: user.id, role: "user", content: message },
      { conversation_id: conversationId, owner_id: user.id, role: "assistant", content: reply },
    ]);
    if (error) return jsonError(500, "DB_ERROR", "Het antwoord is gemaakt, maar opslaan is niet gelukt.", { text: reply, conversationId });
  }
  return NextResponse.json({ text: reply, conversationId: conversationId ?? null });
}
