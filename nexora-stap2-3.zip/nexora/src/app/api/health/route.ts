import { NextResponse } from "next/server";
import { isSupabaseConfigured } from "@/lib/env";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

// Geeft alleen een globale status terug; geen details die aanvallers helpen.
export async function GET() {
  let db: "ok" | "error" | "not_configured" = "not_configured";
  if (isSupabaseConfigured()) {
    try {
      const supabase = await createClient();
      const { error } = await supabase.from("profiles").select("id", { head: true, count: "exact" }).limit(1);
      db = error ? "error" : "ok";
    } catch { db = "error"; }
  }
  const status = db === "error" ? 503 : 200;
  return NextResponse.json({ status: db === "error" ? "degraded" : "ok", db, time: new Date().toISOString() }, { status });
}
