import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// Geblokkeerde gebruikers worden uitgelogd (cookies wijzigen kan niet vanuit een layout).
export async function GET(request: Request) {
  const supabase = await createClient();
  await supabase.auth.signOut();
  return NextResponse.redirect(new URL("/login?fout=geblokkeerd", request.url));
}
