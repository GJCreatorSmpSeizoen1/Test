import type { Metadata } from "next";
export const metadata: Metadata = { title: "Privacyverklaring" };

export default function Privacy() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-10 space-y-4">
      <p className="alert alert-warn">Concepttekst. Laat deze verklaring juridisch controleren en aanvullen met je eigen bedrijfsgegevens voordat je live gaat.</p>
      <h1 className="text-3xl font-bold">Privacyverklaring</h1>
      <h2 className="text-xl font-semibold">Welke gegevens we bewaren</h2>
      <p className="text-mut">Je e-mailadres, naam en wachtwoord (versleuteld door Supabase Auth), je projecten en, alleen als je daarvoor kiest, je chatgesprekken. Beheeracties worden vastgelegd in een auditlog.</p>
      <h2 className="text-xl font-semibold">Verwerkers</h2>
      <p className="text-mut">Gegevens staan bij Supabase. Prompts en chatberichten die je naar de AI stuurt, worden verwerkt door de gekoppelde AI-aanbieder om een antwoord te maken.</p>
      <h2 className="text-xl font-semibold">Jouw rechten</h2>
      <p className="text-mut">Je kunt je gegevens inzien, laten corrigeren of verwijderen. Neem hiervoor contact op met de beheerder van dit platform.</p>
    </main>
  );
}
