import type { Metadata } from "next";
export const metadata: Metadata = { title: "Voorwaarden" };

export default function Voorwaarden() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-10 space-y-4">
      <p className="alert alert-warn">Concepttekst. Laat deze voorwaarden juridisch controleren voordat je live gaat.</p>
      <h1 className="text-3xl font-bold">Gebruiksvoorwaarden</h1>
      <p className="text-mut">Door een account aan te maken ga je akkoord met deze voorwaarden. Gebruik Nexora niet voor onwettige doeleinden en deel je inloggegevens niet. De beheerder mag accounts blokkeren bij misbruik.</p>
      <p className="text-mut">AI-antwoorden kunnen fouten bevatten. Controleer belangrijke informatie zelf.</p>
    </main>
  );
}
