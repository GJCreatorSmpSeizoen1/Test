import Link from "next/link";

export default function MarketingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-5">
        <Link href="/" className="brand" style={{ padding: 0 }}>Nexora</Link>
        <nav aria-label="Hoofdmenu" className="flex items-center gap-2 text-sm">
          <Link href="/functies" className="rounded-lg px-3 py-2 text-mut hover:text-fg">Functies</Link>
          <Link href="/login" className="rounded-lg px-3 py-2 text-mut hover:text-fg">Inloggen</Link>
          <Link href="/registreren" className="btn btn-sm">Gratis starten</Link>
        </nav>
      </header>
      <div className="flex-1">{children}</div>
      <footer className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3 border-t border-line px-6 py-6 text-sm text-mut">
        <span>Nexora</span>
        <span className="flex gap-4"><Link href="/privacy" className="hover:text-fg">Privacy</Link><Link href="/voorwaarden" className="hover:text-fg">Voorwaarden</Link></span>
      </footer>
    </div>
  );
}
