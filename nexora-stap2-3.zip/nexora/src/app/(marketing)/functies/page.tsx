import type { Metadata } from "next";
import Link from "next/link";
export const metadata: Metadata = { title: "Functies" };

const ITEMS = [
  ["Projecten", "Toevoegen, hernoemen, status wijzigen, verwijderen, zoeken, filteren en bladeren."],
  ["AI Studio", "Samenvatten, herschrijven en ideeën genereren via een beveiligde server-koppeling. Zonder API-sleutel zie je een duidelijke melding en geen nepantwoord."],
  ["Chat", "Gesprekken met de assistent. Bewaren is een keuze per gesprek."],
  ["Account", "Registreren, inloggen, wachtwoord herstellen, profiel en wachtwoord wijzigen."],
  ["Beheer", "Gebruikers bekijken, rollen toewijzen, accounts blokkeren en een auditlog van beheeracties."],
];

export default function Functies() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="text-3xl font-bold">Functies</h1>
      <dl className="mt-8 grid gap-4">
        {ITEMS.map(([t, d]) => (<div key={t} className="card"><dt className="font-display text-lg font-semibold">{t}</dt><dd className="mt-1 text-mut">{d}</dd></div>))}
      </dl>
      <p className="mt-8"><Link href="/registreren" className="btn">Account aanmaken</Link></p>
    </main>
  );
}
