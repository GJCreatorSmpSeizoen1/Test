import Link from "next/link";

const FEATURES = [
  { t: "Projecten die je terugvindt", d: "Maak projecten aan, zoek en filter ze, werk de status bij. Alles staat in je eigen database-account." },
  { t: "AI Studio", d: "Laat tekst samenvatten, herschrijven of aanvullen met ideeën. Werkt zodra de beheerder een API-sleutel koppelt." },
  { t: "Chat met geheugen naar keuze", d: "Praat met de assistent en kies zelf of een gesprek wordt bewaard." },
  { t: "Afgeschermd per gebruiker", d: "Row Level Security zorgt dat niemand andermans projecten of gesprekken kan lezen." },
  { t: "Beheer met logboek", d: "Beheerders wijzigen rollen en blokkeren accounts. Elke actie komt in een auditlog." },
  { t: "Prettig op elk scherm", d: "Zijbalk op desktop, onderbalk op je telefoon, bruikbaar met toetsenbord." },
];

export default function Landing() {
  return (
    <main>
      <section className="mx-auto grid max-w-6xl items-center gap-12 px-6 pb-20 pt-10 md:grid-cols-2">
        <div>
          <h1 className="text-4xl font-bold leading-tight md:text-5xl">Houd je projecten bij en werk met AI, op één rustige plek.</h1>
          <p className="mt-5 max-w-prose text-lg text-mut">Nexora combineert projectbeheer, een AI Studio en chat. Gemaakt voor mensen die hun werk willen overzien zonder een zwaar systeem.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/registreren" className="btn">Account aanmaken</Link>
            <Link href="/functies" className="btn btn-ghost">Bekijk de functies</Link>
          </div>
        </div>
        <div aria-hidden="true" className="card" style={{ background: "linear-gradient(160deg,#17112b,var(--panel))" }}>
          <div className="mb-4 grid grid-cols-3 gap-3">
            {[["Actief", "4"], ["Gepland", "7"], ["Afgerond", "12"]].map(([l, n]) => (
              <div key={l} className="rounded-xl border border-line bg-panel2 p-3"><div className="text-xs text-mut">{l}</div><div className="font-display text-2xl font-bold">{n}</div></div>
            ))}
          </div>
          <div className="bars">{[40, 65, 55, 90, 70, 30, 45].map((h, i) => <div key={i} style={{ height: `${h}%` }} />)}</div>
          <p className="mt-3 text-xs text-mut">Voorbeeldweergave</p>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <h2 className="mb-6 text-2xl font-bold">Wat je met Nexora kunt</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (<div key={f.t} className="card"><h3 className="text-lg font-semibold">{f.t}</h3><p className="mt-2 text-mut">{f.d}</p></div>))}
        </div>
        <div className="mt-12 card flex flex-wrap items-center justify-between gap-4">
          <div><h2 className="text-xl font-bold">Klaar om te beginnen?</h2><p className="text-mut">Registreren kost een minuut.</p></div>
          <Link href="/registreren" className="btn">Gratis starten</Link>
        </div>
      </section>
    </main>
  );
}
