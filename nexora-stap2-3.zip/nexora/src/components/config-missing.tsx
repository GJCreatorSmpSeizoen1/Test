export function ConfigMissing() {
  return (
    <main className="mx-auto max-w-xl px-6 py-20">
      <div className="alert alert-warn" role="alert">
        <strong>Supabase is nog niet ingesteld.</strong>
        <p className="mt-2">Vul NEXT_PUBLIC_SUPABASE_URL en NEXT_PUBLIC_SUPABASE_ANON_KEY in .env.local (lokaal) of bij Vercel onder Environment Variables. Zie README.md.</p>
      </div>
    </main>
  );
}
