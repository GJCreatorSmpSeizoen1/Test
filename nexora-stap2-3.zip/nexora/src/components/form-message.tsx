import type { ActionState } from "@/lib/types";

export function FormMessage({ state }: { state: ActionState }) {
  if (state.error) return <p role="alert" className="alert alert-err">{state.error}</p>;
  if (state.message) return <p role="status" className="alert alert-ok">{state.message}</p>;
  return null;
}
