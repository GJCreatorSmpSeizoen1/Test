import type { InputHTMLAttributes } from "react";

type Props = Omit<InputHTMLAttributes<HTMLInputElement>, "name"> & {
  label: string;
  name: string;
  error?: string[] | undefined;
  hint?: string;
};

export function Field({ label, name, error, hint, ...rest }: Props) {
  const id = `f-${name}`;
  const hasError = Boolean(error?.length);
  const describedBy = [hasError ? `${id}-err` : null, hint ? `${id}-hint` : null].filter(Boolean).join(" ") || undefined;
  return (
    <div>
      <label htmlFor={id} className="label">{label}</label>
      <input id={id} name={name} aria-invalid={hasError ? true : undefined} aria-describedby={describedBy} {...rest} className="input" />
      {hint ? <p id={`${id}-hint`} className="mt-1 text-sm text-mut">{hint}</p> : null}
      {hasError ? <p id={`${id}-err`} className="mt-1 text-sm text-bad">{error?.[0]}</p> : null}
    </div>
  );
}
