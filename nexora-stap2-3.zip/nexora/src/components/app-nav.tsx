"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOutAction } from "@/app/(auth)/actions";

export function AppNav({ items, name }: { items: { href: string; label: string }[]; name: string }) {
  const path = usePathname();
  return (
    <aside className="side">
      <Link href="/dashboard" className="brand">Nexora</Link>
      <nav className="nav" aria-label="Hoofdmenu">
        {items.map((i) => {
          const active = path === i.href || path.startsWith(i.href + "/");
          return <Link key={i.href} href={i.href} className="navlink" aria-current={active ? "page" : undefined}>{i.label}</Link>;
        })}
      </nav>
      <div className="side-foot">
        <span className="truncate">{name}</span>
        <form action={signOutAction}><button className="btn btn-ghost btn-sm" type="submit">Uitloggen</button></form>
      </div>
    </aside>
  );
}
