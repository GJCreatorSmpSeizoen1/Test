// Eenvoudige in-memory limiter. LET OP: op serverless (Vercel) heeft elke instance eigen geheugen,
// dus dit is een eerste rem, geen harde garantie. Gebruik voor productie een gedeelde opslag (bijv. Upstash Redis of een databasetabel).
interface Bucket { count: number; reset: number }
const buckets = new Map<string, Bucket>();

export function rateLimit(key: string, limit: number, windowMs: number, now = Date.now()) {
  if (buckets.size > 5000) for (const [k, b] of buckets) if (b.reset <= now) buckets.delete(k);
  const b = buckets.get(key);
  if (!b || b.reset <= now) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    return { ok: true, remaining: limit - 1, retryAfterSec: 0 };
  }
  if (b.count >= limit) return { ok: false, remaining: 0, retryAfterSec: Math.ceil((b.reset - now) / 1000) };
  b.count += 1;
  return { ok: true, remaining: limit - b.count, retryAfterSec: 0 };
}
export function resetRateLimits() { buckets.clear(); }
