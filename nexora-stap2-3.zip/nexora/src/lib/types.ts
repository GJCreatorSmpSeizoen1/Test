export type Role = "user" | "moderator" | "admin";
export type ProjectStatus = "planned" | "active" | "done";

export interface Profile {
  id: string;
  display_name: string;
  role: Role;
  is_active: boolean;
  notify_email: boolean;
  created_at: string;
}
export interface Project {
  id: string;
  name: string;
  status: ProjectStatus;
  created_at: string;
}
export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}
/** Resultaat van een server action voor formulieren (useActionState). */
export interface ActionState {
  ok?: boolean;
  message?: string;
  error?: string;
  fieldErrors?: Record<string, string[] | undefined>;
  values?: Record<string, string>;
}
