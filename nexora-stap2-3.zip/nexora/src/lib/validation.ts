import { z } from "zod";

export const emailSchema = z.string().trim().toLowerCase().email("Vul een geldig e-mailadres in").max(254);
export const passwordSchema = z.string().min(10, "Gebruik minimaal 10 tekens").max(72, "Gebruik maximaal 72 tekens");
export const displayNameSchema = z.string().trim().min(1, "Vul je naam in").max(40, "Maximaal 40 tekens");

export const registerSchema = z.object({ displayName: displayNameSchema, email: emailSchema, password: passwordSchema });
export const loginSchema = z.object({ email: emailSchema, password: z.string().min(1, "Vul je wachtwoord in").max(72) });
export const forgotSchema = z.object({ email: emailSchema });
export const newPasswordSchema = z
  .object({ password: passwordSchema, confirm: z.string() })
  .refine((d) => d.password === d.confirm, { message: "Wachtwoorden komen niet overeen", path: ["confirm"] });

export const projectNameSchema = z.string().trim().min(1, "Vul een projectnaam in").max(60, "Maximaal 60 tekens");
export const profileSchema = z.object({ displayName: displayNameSchema, notifyEmail: z.boolean() });

export const uuidSchema = z.string().uuid();
export const roleSchema = z.enum(["user", "moderator", "admin"]);

export const aiPromptSchema = z.object({
  prompt: z.string().trim().min(1, "Schrijf eerst een prompt").max(4000, "Maximaal 4000 tekens"),
  mode: z.enum(["summarize", "rewrite", "ideas", "free"]).default("free"),
});
export const chatSchema = z.object({
  message: z.string().trim().min(1, "Schrijf eerst een bericht").max(4000, "Maximaal 4000 tekens"),
  conversationId: z.string().uuid().optional(),
  save: z.boolean().default(false),
  history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(20000) })).max(20).default([]),
});
