import "server-only";
import { cache } from "react";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/lib/types";

/** Haalt de ingelogde gebruiker en het profiel op (1x per request gecached). Altijd server-side verifieerd via getUser(). */
export const getSessionProfile = cache(async () => {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { user: null, profile: null as Profile | null };
  const { data } = await supabase
    .from("profiles")
    .select("id,display_name,role,is_active,notify_email,created_at")
    .eq("id", user.id)
    .maybeSingle();
  return { user, profile: (data as Profile | null) };
});

export async function requireUser() {
  const { user, profile } = await getSessionProfile();
  if (!user) redirect("/login");
  if (!profile) throw new Error("Profiel niet gevonden. Controleer of de databasemigratie is toegepast.");
  if (!profile.is_active) redirect("/auth/geblokkeerd");
  return { user, profile };
}

/** Alleen beheerders. Wie geen admin is krijgt een 404 (bestaan van de pagina wordt niet verraden). */
export async function requireAdmin() {
  const ctx = await requireUser();
  if (ctx.profile.role !== "admin") notFound();
  return ctx;
}
