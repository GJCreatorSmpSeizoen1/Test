import "server-only";
import { getServerEnv } from "@/lib/env";

export class AiNotConfiguredError extends Error {}
export class AiUpstreamError extends Error {
  status: number;
  constructor(status: number, message: string) { super(message); this.status = status; }
}
export interface AiMessage { role: "user" | "assistant"; content: string }

export const SYSTEM_PROMPTS = {
  summarize: "Vat de tekst van de gebruiker beknopt samen in het Nederlands.",
  rewrite: "Herschrijf de tekst helderder en professioneler, in dezelfde taal als de invoer.",
  ideas: "Bedenk vijf concrete ideeën bij het onderwerp, elk met één zin uitleg, in het Nederlands.",
  free: "Je bent een behulpzame assistent binnen Nexora. Antwoord beknopt en in de taal van de gebruiker.",
  chat: "Je bent de assistent in Nexora-chat. Antwoord helder en beknopt, in de taal van de gebruiker.",
} as const;

/** Roept de Anthropic Messages API aan vanaf de server. De sleutel verlaat de server nooit en wordt niet gelogd. */
export async function generate(opts: { system?: string; messages: AiMessage[]; maxTokens?: number }): Promise<string> {
  const env = getServerEnv();
  if (!env.ANTHROPIC_API_KEY) throw new AiNotConfiguredError("ANTHROPIC_API_KEY ontbreekt");
  let res: Response;
  try {
    res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: env.AI_MODEL, max_tokens: opts.maxTokens ?? 1024, system: opts.system, messages: opts.messages }),
      signal: AbortSignal.timeout(30_000),
    });
  } catch {
    throw new AiUpstreamError(504, "De AI-service reageerde niet op tijd of was onbereikbaar.");
  }
  if (!res.ok) throw new AiUpstreamError(res.status, `De AI-service gaf status ${res.status}.`);
  const data = (await res.json()) as { content?: { type: string; text?: string }[] };
  const text = (data.content ?? []).filter((b) => b.type === "text").map((b) => b.text ?? "").join("").trim();
  if (!text) throw new AiUpstreamError(502, "De AI-service gaf een leeg antwoord.");
  return text;
}
