import { beforeEach, describe, expect, it } from "vitest";
import { rateLimit, resetRateLimits } from "@/lib/rate-limit";

describe("rateLimit", () => {
  beforeEach(() => resetRateLimits());
  it("blokkeert na het maximum en geeft retry-tijd", () => {
    expect(rateLimit("a", 2, 1000, 0).ok).toBe(true);
    expect(rateLimit("a", 2, 1000, 10).ok).toBe(true);
    const third = rateLimit("a", 2, 1000, 20);
    expect(third.ok).toBe(false);
    expect(third.retryAfterSec).toBe(1);
  });
  it("opent opnieuw na het venster en scheidt sleutels", () => {
    rateLimit("a", 1, 1000, 0);
    expect(rateLimit("a", 1, 1000, 500).ok).toBe(false);
    expect(rateLimit("b", 1, 1000, 500).ok).toBe(true);
    expect(rateLimit("a", 1, 1000, 1001).ok).toBe(true);
  });
});
