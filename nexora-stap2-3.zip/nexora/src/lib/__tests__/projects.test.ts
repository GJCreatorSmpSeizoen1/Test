import { describe, expect, it } from "vitest";
import { escapeLike, nextStatus, pageRange, parsePage, parseStatus } from "@/lib/projects";

describe("projecthelpers", () => {
  it("wisselt status in een cirkel", () => {
    expect(nextStatus("planned")).toBe("active");
    expect(nextStatus("active")).toBe("done");
    expect(nextStatus("done")).toBe("planned");
  });
  it("parseert status en pagina veilig", () => {
    expect(parseStatus("active")).toBe("active");
    expect(parseStatus("hack")).toBe(undefined);
    expect(parsePage("3")).toBe(3);
    expect(parsePage("-1")).toBe(1);
    expect(parsePage("abc")).toBe(1);
    expect(parsePage("999999")).toBe(10000);
  });
  it("berekent paginabereik", () => {
    expect(pageRange(1)).toEqual({ from: 0, to: 9 });
    expect(pageRange(3)).toEqual({ from: 20, to: 29 });
  });
  it("escapet LIKE-tekens", () => {
    expect(escapeLike("50%_a\\b")).toBe("50\\%\\_a\\\\b");
  });
});
