import { describe, expect, it } from "vitest";
import { aiPromptSchema, chatSchema, loginSchema, newPasswordSchema, projectNameSchema, registerSchema, roleSchema } from "@/lib/validation";

describe("validatie", () => {
  it("registratie: geldig en ongeldig", () => {
    expect(registerSchema.safeParse({ displayName: "Sam", email: " SAM@Example.com ", password: "langwachtwoord1" }).success).toBe(true);
    expect(registerSchema.safeParse({ displayName: "", email: "x", password: "kort" }).success).toBe(false);
  });
  it("registratie normaliseert e-mail", () => {
    const r = registerSchema.parse({ displayName: "Sam", email: " SAM@Example.com ", password: "langwachtwoord1" });
    expect(r.email).toBe("sam@example.com");
  });
  it("login vereist wachtwoord", () => {
    expect(loginSchema.safeParse({ email: "a@b.nl", password: "" }).success).toBe(false);
  });
  it("nieuw wachtwoord moet overeenkomen", () => {
    expect(newPasswordSchema.safeParse({ password: "langwachtwoord1", confirm: "anders" }).success).toBe(false);
    expect(newPasswordSchema.safeParse({ password: "langwachtwoord1", confirm: "langwachtwoord1" }).success).toBe(true);
  });
  it("projectnaam: lengtegrenzen", () => {
    expect(projectNameSchema.safeParse("   ").success).toBe(false);
    expect(projectNameSchema.safeParse("x".repeat(61)).success).toBe(false);
    expect(projectNameSchema.safeParse("Goed").success).toBe(true);
  });
  it("rollen en AI-invoer", () => {
    expect(roleSchema.safeParse("root").success).toBe(false);
    expect(aiPromptSchema.safeParse({ prompt: "hoi" }).success).toBe(true);
    expect(aiPromptSchema.safeParse({ prompt: "x".repeat(4001) }).success).toBe(false);
    expect(chatSchema.safeParse({ message: "hoi", conversationId: "geen-uuid" }).success).toBe(false);
  });
});
