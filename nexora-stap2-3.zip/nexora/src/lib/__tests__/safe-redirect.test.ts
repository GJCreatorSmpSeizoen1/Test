import { describe, expect, it } from "vitest";
import { safeNext } from "@/lib/safe-redirect";

describe("safeNext", () => {
  it("laat interne paden door", () => {
    expect(safeNext("/projecten?page=2")).toBe("/projecten?page=2");
  });
  it("valt terug bij externe of onveilige waarden", () => {
    expect(safeNext("https://evil.example")).toBe("/dashboard");
    expect(safeNext("//evil.example")).toBe("/dashboard");
    expect(safeNext("/\\evil.example")).toBe("/dashboard");
    expect(safeNext("/ok\nSet-Cookie: x")).toBe("/dashboard");
    expect(safeNext(null)).toBe("/dashboard");
    expect(safeNext(undefined, "/x")).toBe("/x");
  });
});
