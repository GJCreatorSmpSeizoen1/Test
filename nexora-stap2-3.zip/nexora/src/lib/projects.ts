import type { ProjectStatus } from "./types";

export const STATUSES: readonly ProjectStatus[] = ["planned", "active", "done"];
export const STATUS_LABEL: Record<ProjectStatus, string> = { planned: "Gepland", active: "Actief", done: "Afgerond" };
export const PAGE_SIZE = 10;

export function nextStatus(s: ProjectStatus): ProjectStatus {
  const i = STATUSES.indexOf(s);
  return STATUSES[(i + 1) % STATUSES.length] ?? "planned";
}
export function parseStatus(v: string | undefined | null): ProjectStatus | undefined {
  return STATUSES.find((s) => s === v);
}
export function parsePage(v: string | undefined | null): number {
  const n = Number.parseInt(v ?? "1", 10);
  return Number.isFinite(n) && n >= 1 ? Math.min(n, 10000) : 1;
}
export function pageRange(page: number): { from: number; to: number } {
  const from = (page - 1) * PAGE_SIZE;
  return { from, to: from + PAGE_SIZE - 1 };
}
/** Escape % _ en \ zodat zoektekst niet als LIKE-patroon werkt. */
export function escapeLike(s: string): string {
  return s.replace(/[\\%_]/g, (m) => "\\" + m);
}
