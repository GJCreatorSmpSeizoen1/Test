import { NextResponse } from "next/server";

export function jsonError(status: number, error: string, message: string, extra?: Record<string, unknown>, headers?: Record<string, string>) {
  return NextResponse.json({ error, message, ...extra }, { status, headers });
}
