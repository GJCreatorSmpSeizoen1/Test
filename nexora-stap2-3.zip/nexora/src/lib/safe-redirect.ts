/** Alleen interne paden toestaan; voorkomt open redirects via ?next=. */
export function safeNext(v: string | null | undefined, fallback = "/dashboard"): string {
  if (!v) return fallback;
  if (!v.startsWith("/") || v.startsWith("//") || v.includes("\\") || /[\r\n\t]/.test(v)) return fallback;
  return v;
}
