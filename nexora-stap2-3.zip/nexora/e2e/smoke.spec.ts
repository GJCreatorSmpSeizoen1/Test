import { expect, test } from "@playwright/test";

test("landingpage toont kop en registratielink", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
  await page.getByRole("link", { name: "Account aanmaken" }).first().click();
  await expect(page).toHaveURL(/registreren/);
});

test("functies, privacy en voorwaarden zijn bereikbaar", async ({ page }) => {
  for (const [path, name] of [["/functies", "Functies"], ["/privacy", "Privacyverklaring"], ["/voorwaarden", "Gebruiksvoorwaarden"]]) {
    await page.goto(path as string);
    await expect(page.getByRole("heading", { name: name as string })).toBeVisible();
  }
});

// De volgende tests hebben echte Supabase-variabelen nodig (zet E2E_SUPABASE=1 bij een geconfigureerde omgeving).
test("beveiligde pagina stuurt naar inloggen", async ({ page }) => {
  test.skip(!process.env.E2E_SUPABASE, "Supabase niet geconfigureerd voor e2e");
  await page.goto("/dashboard");
  await expect(page).toHaveURL(/login/);
});

test("inloggen met leeg formulier toont geen dode knop", async ({ page }) => {
  test.skip(!process.env.E2E_SUPABASE, "Supabase niet geconfigureerd voor e2e");
  await page.goto("/login");
  await expect(page.getByLabel("E-mailadres")).toBeVisible();
  await expect(page.getByRole("button", { name: "Inloggen" })).toBeEnabled();
});
