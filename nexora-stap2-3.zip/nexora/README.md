# Nexora

Next.js (App Router) + TypeScript + Tailwind + Supabase. Design: `design/preview-reference.html`. Voortgang en wat NIET getest is: zie `TODO.md`.

## Lokaal starten
```bash
npm install
cp .env.example .env.local     # vul de waarden in
npm run typecheck && npm run lint && npm run build
npm run dev
```

## Supabase instellen
1. Maak een project op supabase.com. Kopieer URL, anon key en service-role key naar `.env.local`.
2. Voer `supabase/migrations/0001_init.sql` uit (SQL-editor of `supabase db push`).
3. Authentication > URL Configuration: zet Site URL op je domein en voeg `<jouw-url>/auth/callback` toe aan Redirect URLs.
4. Eerste beheerder: registreer een account en voer uit in de SQL-editor:
   `update public.profiles set role = 'admin' where id = '<user-id>';`

## AI inschakelen
Zet `ANTHROPIC_API_KEY` (en eventueel `AI_MODEL`) als omgevingsvariabele op de server. Controleer de modelnaam in de Anthropic-documentatie. Zonder sleutel tonen AI Studio en chat een duidelijke melding.

## Tests
```bash
npm test                        # Vitest (unit)
npx playwright install chromium && npm run test:e2e
E2E_SUPABASE=1 npm run test:e2e # ook tests die Supabase nodig hebben
```

## Scripts (service-role, handmatig of via cron/CI)
```bash
npm run script:health
npm run script:cleanup -- --days=90               # dry-run
npm run script:cleanup -- --days=90 --apply --yes # echt verwijderen
```

## Vercel
```bash
npm i -g vercel
vercel          # preview
vercel --prod   # productie
```
Zet alle variabelen uit `.env.example` bij Vercel > Settings > Environment Variables (SUPABASE_SERVICE_ROLE_KEY en ANTHROPIC_API_KEY nooit met NEXT_PUBLIC_).

## Productie- en beveiligingschecklist
- [ ] Migratie toegepast, RLS aan op alle tabellen (standaard in de migratie)
- [ ] Redirect URLs in Supabase kloppen
- [ ] Geen sleutels in Git (`.env*` staat in .gitignore)
- [ ] Rate limiting vervangen door gedeelde opslag
- [ ] Privacy- en voorwaardentekst juridisch gecontroleerd
- [ ] Healthcheck `/api/health` en foutmonitoring ingesteld
