// Controleert of de database bereikbaar is en de verwachte tabellen bestaan. Alleen lezen. Exitcode 1 bij een probleem.
import { serviceClient } from "./lib.mjs";

const TABLES = ["profiles", "projects", "conversations", "messages", "notifications", "audit_logs"];
const db = serviceClient();
let failed = false;
for (const t of TABLES) {
  const { count, error } = await db.from(t).select("*", { count: "exact", head: true });
  if (error) { failed = true; console.error(`FOUT  ${t}: ${error.message}`); }
  else console.log(`OK    ${t}: ${count ?? 0} rijen`);
}
if (failed) { console.error("Healthcheck mislukt."); process.exit(1); }
console.log("Healthcheck geslaagd.");
