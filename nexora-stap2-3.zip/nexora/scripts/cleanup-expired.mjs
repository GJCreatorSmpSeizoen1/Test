// Verwijdert GELEZEN meldingen ouder dan N dagen.
// Veilig: standaard alleen tellen (dry-run). Verwijderen vereist --apply --yes. Herhaald uitvoeren is veilig.
// Gebruik: npm run script:cleanup -- --days=90            (dry-run)
//          npm run script:cleanup -- --days=90 --apply --yes
import { parseArgs, serviceClient } from "./lib.mjs";

const args = parseArgs(process.argv.slice(2));
const days = Number.parseInt(String(args.days ?? "90"), 10);
if (!Number.isInteger(days) || days < 7 || days > 3650) { console.error("Fout: --days moet een geheel getal tussen 7 en 3650 zijn."); process.exit(2); }
const apply = args.apply === true;
if (apply && args.yes !== true) { console.error("Fout: --apply vereist ook --yes (bevestiging)."); process.exit(2); }

const cutoff = new Date(Date.now() - days * 86_400_000).toISOString();
const db = serviceClient();
const { count, error } = await db.from("notifications").select("id", { count: "exact", head: true }).not("read_at", "is", null).lt("read_at", cutoff);
if (error) { console.error("Fout bij tellen:", error.message); process.exit(1); }
console.log(`${count ?? 0} gelezen meldingen ouder dan ${days} dagen (voor ${cutoff}).`);
if (!apply) { console.log("Dry-run: er is niets verwijderd. Gebruik --apply --yes om te verwijderen."); process.exit(0); }

let deleted = 0;
for (;;) {
  const { data, error: selErr } = await db.from("notifications").select("id").not("read_at", "is", null).lt("read_at", cutoff).limit(500);
  if (selErr) { console.error("Fout:", selErr.message); process.exit(1); }
  if (!data || data.length === 0) break;
  const { error: delErr } = await db.from("notifications").delete().in("id", data.map((r) => r.id));
  if (delErr) { console.error("Fout bij verwijderen:", delErr.message); process.exit(1); }
  deleted += data.length;
}
await db.from("audit_logs").insert({ actor_id: null, action: "maintenance.cleanup_notifications", target_type: "notifications", meta: { deleted, days } });
console.log(`Klaar: ${deleted} meldingen verwijderd.`);
